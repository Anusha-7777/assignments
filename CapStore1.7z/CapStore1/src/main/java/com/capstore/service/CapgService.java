package com.capstore.service;

import java.util.List;

import com.capstore.bean.Feedback;



public interface CapgService {
	public Feedback addFeedback(Feedback feedback);
	 public List<Feedback> getFeedback();
}
