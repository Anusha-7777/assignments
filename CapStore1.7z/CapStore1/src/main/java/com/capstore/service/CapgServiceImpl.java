package com.capstore.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.capstore.bean.Customer;
import com.capstore.bean.Feedback;
import com.capstore.bean.WishItem;
import com.capstore.dao.CustomerDao;
import com.capstore.dao.FeedbackDao;
import com.capstore.dao.WishItemDao;

@Service
public class CapgServiceImpl implements CapgService {

	@Autowired
	FeedbackDao feedbackDao;

	@Override
	public Feedback addFeedback(Feedback feedback) {
		// TODO Auto-generated method stub
		return feedbackDao.save(feedback);
	}

	@Override
	public List<Feedback> getFeedback() {
		// TODO Auto-generated method stub
		return feedbackDao.findAll();
	}
	
	
}
