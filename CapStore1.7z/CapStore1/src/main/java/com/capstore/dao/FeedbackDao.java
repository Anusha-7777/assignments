package com.capstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capstore.bean.Feedback;


@Repository

	public interface FeedbackDao extends JpaRepository<Feedback, String> {
	//	@Query("from Feedback where custId=:custid")
	  // Feedback getFeedbackBycustId(@Param("custid") String custId);

}

