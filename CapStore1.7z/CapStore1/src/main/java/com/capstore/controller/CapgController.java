package com.capstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.capstore.bean.Customer;
import com.capstore.bean.Feedback;
import com.capstore.bean.WishItem;
import com.capstore.service.CapgService;
@CrossOrigin("http://localhost:4200")
@RestController
public class CapgController {

	@Autowired CapgService capgService;
	
	@RequestMapping("/ecommerce/186108/getFeedback")
	public List<Feedback> getFeedback()
	{
		return capgService.getFeedback();
		
	}
	@RequestMapping(value="/ecommerce/186108/addFeedback",method=RequestMethod.POST)
	public Feedback addFeedback(@RequestBody Feedback feedback) 
	{
	    return capgService.addFeedback(feedback);
	}
}
