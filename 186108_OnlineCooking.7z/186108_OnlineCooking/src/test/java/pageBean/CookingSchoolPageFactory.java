package pageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;


public class CookingSchoolPageFactory {
WebDriver driver;

@FindBy(name="fname")
@CacheLookup
WebElement Fname;

@FindBy(name="lname")
@CacheLookup
WebElement Lname;

@FindBy(name="email")
@CacheLookup
WebElement pfemail;

@FindBy(name="mobile")
@CacheLookup
WebElement pfmobile;

@FindBy(name="D6")
@CacheLookup
WebElement recipe;

@FindBy(name="D5")
@CacheLookup
WebElement city;

@FindBy(name="D4")
@CacheLookup
WebElement training;

public WebElement getTraining() {
	return training;
}

public void setTraining(WebElement training) {
	this.training = training;
}

@FindBy(name="D4")
@CacheLookup
WebElement months;

@FindBy(name="enqdetails")
@CacheLookup
WebElement details;

public WebDriver getDriver() {
	return driver;
}

public void setDriver(WebDriver driver) {
	this.driver = driver;
}

public WebElement getFname() {
	return Fname;
}

public void setFname(WebElement fname) {
	Fname = fname;
}

public WebElement getLname() {
	return Lname;
}

public void setLname(WebElement lname) {
	Lname = lname;
}

public WebElement getPfemail() {
	return pfemail;
}

public void setPfemail(WebElement pfemail) {
	this.pfemail = pfemail;
}

public WebElement getPfmobile() {
	return pfmobile;
}

public void setPfmobile(WebElement pfmobile) {
	this.pfmobile = pfmobile;
}

public WebElement getRecipe() {
	return recipe;
}

public void setRecipe(WebElement recipe) {
	this.recipe = recipe;
}

public WebElement getCity() {
	return city;
}

public void setCity(WebElement city) {
	this.city = city;
}

public WebElement getMonths() {
	return months;
}

public void setMonths(WebElement months) {
	this.months = months;
}

public WebElement getDetails() {
	return details;
}

public void setDetails(WebElement details) {
	this.details = details;
}



}
