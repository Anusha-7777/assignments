package recipeForm;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageBean.CookingSchoolPageFactory;


public class StepDefinition {
	CookingSchoolPageFactory objhbpg;
	 static WebDriver driver=null;
	@Given("^User is on cooking school page$")
	public void user_is_on_cooking_school_page1() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\apragada\\Desktop\\BDD\\chromedriver_win32\\chromedriver.exe");
		//driver = new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		//objhbpg = new CookingSchoolPageFactory(driver);
		driver.get("C:\\Users\\apragada\\Desktop\\OnlineCooking\\Recipe_class_registration.html");
	}
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
	

	@Then("^check the title of the page$")
	public void check_the_title_of_the_page() throws Throwable {
		String title=driver.getTitle();
		if(title.contentEquals("Hotel Booking")) 
			System.out.println("Page Title Matched");
		else System.out.println("Page Title NOT Matched");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		driver.close();
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
	}

	@When("^user enters all valid data$")
	public void user_enters_all_valid_data() throws Throwable {
		objhbpg.setFname(fname);;	Thread.sleep(1000);
		objhbpg.setLname(lname); ;	Thread.sleep(1000);
		objhbpg.setPfemail(pfemail);	Thread.sleep(1000);
		objhbpg.setPfmobile(pfmobile);	Thread.sleep(1000);
	
		objhbpg.setCity(city);	Thread.sleep(1000);
		objhbpg.setMonths(months);Thread.sleep(1000);
		objhbpg.setTraining(training);;	Thread.sleep(1000);
		
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
	}

	@Then("^navigate to welcome page$")
	public void navigate_to_welcome_page() throws Throwable {
		driver.navigate().to("C:\\Users\\apragada\\Desktop\\OnlineCooking\\msg.html");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	}

	@When("^user enters no data in the first Name textbox$")
	public void user_enters_no_data_in_the_first_Name_textbox() throws Throwable {
		objhbpg.setFname("");	Thread.sleep(1000);
	}

	

	@Then("^display 'First name must be filled out in the alert box\\.'$")
	public void display_First_name_must_be_filled_out_in_the_alert_box() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("******" + alertMessage);
	    driver.close();
	}

	@When("^user enters no data in the last Name textbox$")
	public void user_enters_no_data_in_the_last_Name_textbox() throws Throwable {
		objhbpg.setFname("Anusha");	Thread.sleep(1000);
		objhbpg.setLname("");	Thread.sleep(1000);
	}

	@Then("^display  'Last name must be filled out in the alert box\\.'$")
	public void display_Last_name_must_be_filled_out_in_the_alert_box() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("******" + alertMessage);
	    driver.close();
	}
	



	@Then("^Display message 'successful email'$")
	public void display_message_successful_email() throws Throwable {
		objhbpg.setemail("anusha123@gmail.com");	Thread.sleep(1000);
	}

	@Given("^user is on 'cooking school' page$")
	public void user_is_on_cooking_school_page() throws Throwable {
	   
	}

	@When("^user enters invalid mobile number$")
	public void user_enters_invalid_mobile_number() throws Throwable {
		objhbpg.setfname("Anusha");	Thread.sleep(1000);
		objhbpg.setlname("Pragada");	Thread.sleep(1000);
		objhbpg.setemail("anusha123@gmail.com");	Thread.sleep(1000);
		objhbpg.getmobile("");	Thread.sleep(1000);

		
	}

	@Then("^display 'Enter numeric value in the alert box\\.'$")
	public void display_Enter_numeric_value_in_the_alert_box() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user enters incorrect mobileNo format$")
	public void user_enters_incorrect_mobileNo_format() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^display 'Enter (\\d+) digit Mobile Number  in the alert box\\.'$")
	public void display_Enter_digit_Mobile_Number_in_the_alert_box(int arg1) throws Throwable {
		objhbpg.getFname();	Thread.sleep(1000);
		objhbpg.setLname(lname);	Thread.sleep(1000);
		objhbpg.setPfemail("pfemail);
		Thread.sleep(1000);
				
		List<String> objList = arg1.asList(String.class);
		
		
		for(int i=0; i<objList.size(); i++) {
			if(Pattern.matches("^[7-9]{1}[0-9]{9}$", objList.get(i))) {
			System.out.println("***** Valid phone number as per pattern" + objList.get(i) + "*****");
			}
			else {
				System.out.println("***** InValid phone number as per pattern" + objList.get(i) + "*****");
			}
		}
		
	}


	@Given("^user clicks on 'Non-Veg'$")
	public void user_clicks_on_Non_Veg() throws Throwable {
	    
	}

	@Given("^user clicks on 'Mumbai'$")
	public void user_clicks_on_Mumbai() throws Throwable {
	    ;
	}

	@Given("^user clicks on 'In house training'$")
	public void user_clicks_on_In_house_training() throws Throwable {
	    
	}

	@Given("^user clicks on '(\\d+) months'$")
	public void user_clicks_on_months(int arg1) throws Throwable {
	    objhbpg.getMonths();
	}

	@When("^User clicks on enquire button$")
	public void user_clicks_on_enquire_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^display 'Enquiry details must be filled out in the alert box\\.'$")
	public void display_Enquiry_details_must_be_filled_out_in_the_alert_box() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User enters the Enquiry details$")
	public void user_enters_the_Enquiry_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user clicks on Enquire Now button$")
	public void user_clicks_on_Enquire_Now_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^display the message as 'Thank you for submitting the online receipe class Enquiry\\.'$")
	public void display_the_message_as_Thank_you_for_submitting_the_online_receipe_class_Enquiry() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User clicks the ok button of  thank you message$")
	public void user_clicks_the_ok_button_of_thank_you_message() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^dispaly the message as 'Our location representative will contact you soon\\.'$")
	public void dispaly_the_message_as_Our_location_representative_will_contact_you_soon() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user clicks the hyperlink$")
	public void user_clicks_the_hyperlink() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^dispaly the message as 'Recipe class Brochure is sent to your registered mail id\\.'$")
	public void dispaly_the_message_as_Recipe_class_Brochure_is_sent_to_your_registered_mail_id() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}


}
