
package com.cg.proapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.proapp.bean.Product;
import com.cg.proapp.dao.IProductRepo;
import com.cg.proapp.Exception.ProductException;
@Service
public class ProductServiceImpl implements IProductService {
@Autowired
IProductRepo productDao;
/*Creator:Anusha Pragada
Date Of Creation: 30th july,2019
Method Name: getaLLProductS
Parameters Of Method:Product Object
Return Value:void
Purpose Of Method:For getAll products */
	@Override
	public List<Product> getAllProducts() throws ProductException {
	try {
		return productDao.findAll();
	}
	catch(Exception e) {
		throw new ProductException(e.getMessage());
	}
	}
	/*Creator:Anusha Pragada
    Date Of Creation: 30th july,2019
    Method Name: getProductById
    Parameters Of Method:Product Object
    Return Value:void
    Purpose Of Method:For getting product by id */

	@Override
	public Product getProductById(String id) throws ProductException{
		try {
		return productDao.findById(id).get();
		}
		catch(Exception e) {
			throw new ProductException(e.getMessage());
		}
	}
	/*Creator:Anusha Pragada
    Date Of Creation: 30th july,2019
    Method Name: updateProduct
    Parameters Of Method:Product Object
    Return Value:void
    Purpose Of Method:For updating new products */

	@Override
	public void updateProduct(Product pro)throws ProductException {
		try {
		productDao.save(pro);
	}
		catch(Exception e) {
			throw new ProductException(e.getMessage());
		}
	}
	 /*Creator:Anusha Pragada
    Date Of Creation: 30th july,2019
    Method Name: addProduct
    Parameters Of Method:Product Object
    Return Value:void
    Purpose Of Method:For adding new products */

	@Override
	public void addProduct(Product pro)throws ProductException {
		try {
		productDao.save(pro);
		}
		catch(Exception e) {
			throw new ProductException(e.getMessage());
		}
		
	}
	 /*Creator:Anusandhya Suthar
    Date Of Creation: 30th july,2019
    Method Name: deleteProduct
    Parameters Of Method:Product Object
    Return Value:void
    Purpose Of Method:For deleting products */
	@Override
	public void deleteProduct(String id)throws ProductException {
		try {
		productDao.deleteById(id);
		}
		catch(Exception e) {
			throw new ProductException(e.getMessage());
		}
	}
	

	

}
