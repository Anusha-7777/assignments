
package com.cg.proapp.service;

import java.util.List;

import com.cg.proapp.Exception.ProductException;
import com.cg.proapp.bean.Product;



public interface IProductService {
	List<Product>getAllProducts() throws ProductException;
    Product getProductById(String id)throws ProductException;
    void updateProduct(Product pro)throws ProductException;
    void addProduct(Product pro)throws ProductException;
    void deleteProduct(String id)throws ProductException;
    
    
}