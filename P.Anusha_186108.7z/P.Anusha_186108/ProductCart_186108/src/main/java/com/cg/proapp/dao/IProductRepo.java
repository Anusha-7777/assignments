
package com.cg.proapp.dao;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.proapp.bean.Product;

@Repository
public interface IProductRepo extends JpaRepository<Product, String> {

	

}

