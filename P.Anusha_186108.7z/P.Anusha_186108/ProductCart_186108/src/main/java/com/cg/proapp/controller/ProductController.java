
package com.cg.proapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.bind.annotation.RestController;

import com.cg.proapp.bean.Product;
import com.cg.proapp.service.ProductServiceImpl;

@RestController
public class ProductController {
	@Autowired
	ProductServiceImpl productservice;

	@RequestMapping("/api/products")
	public List<Product> getAllProducts() throws Exception {
		return productservice.getAllProducts();
	}

	@RequestMapping("/api/products/{id}")
	public Product getProducts(@PathVariable String id) throws Exception {
		return productservice.getProductById(id);
	}

	@RequestMapping(value = "/api/products/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<String> deleteEmployee(@PathVariable String id) throws Exception {
		productservice.deleteProduct(id);
		return new ResponseEntity<String>("Product with the id " + id + " deleted", HttpStatus.OK);
	}

	@RequestMapping(value = "/api/products", method = RequestMethod.POST)
	public ResponseEntity<String> addEmployee(@RequestBody Product pro) throws Exception {
		productservice.addProduct(pro);
		return new ResponseEntity<String>("Product Successfully added", HttpStatus.OK);
	}

	@RequestMapping(value = "/api/products/{id}", method = RequestMethod.PUT)
	public ResponseEntity<String> updateEmployee(@RequestBody Product pro) throws Exception {
		productservice.updateProduct(pro);
		return new ResponseEntity<String>("Product Successfully update", HttpStatus.OK);
	}

	
}
