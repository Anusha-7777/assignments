package com.service;

import com.bean.Order;
import com.ui.OrderDetails;

public class Validation {

	Order obj=new Order();
	OrderDetails od=new OrderDetails();
	public static boolean validateName(String name)
    {
           String pattern="[A-Z][a-z]*([ ][A-Z][a-z]*)*";
           if(name.matches(pattern))
           return true;
           else
           return false;
    }
	
}
