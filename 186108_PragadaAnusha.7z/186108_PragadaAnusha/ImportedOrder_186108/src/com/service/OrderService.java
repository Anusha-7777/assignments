package com.service;

import com.bean.Order;

public interface OrderService
{
  int calculateOrder(Order bean);
}
