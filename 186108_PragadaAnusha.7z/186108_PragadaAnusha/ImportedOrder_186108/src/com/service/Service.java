package com.service;

import java.util.Map;
import java.util.Scanner;

import com.bean.Order;
import java.util.List;

import com.dao.DataStorage;
import com.bean.Order;
import com.ui.OrderDetails;

public class Service 
{
	  
    Scanner sc = new Scanner(System.in);
    
    Map mapOfOrderArrayList1;
    
     DataStorage dsObj;
     OrderDetails OdObj;
     Order Obj;

	private Map mapOfOrderArrayList;
     public Service(DataStorage dsObj, OrderDetails OdObj, Order Obj)
     {
         this.OdObj = OdObj;
         this.dsObj = dsObj;
         this.Obj = Obj;
     }
   
	
	public void actionOnUserChoice()
     {
         boolean input=true;
         int choice = OdObj.displayMenu();
         if(choice==1)
         {
             
             OdObj.enterImportedDetails(Obj);
             sendDataToDaoClass();
             System.out.print("Do you want to Continue Adding ? (Y/N) : ");
             
             if(sc.next().toLowerCase().equals("y"))
             {
                 actionOnUserChoice();}
             
             else if(sc.next().toLowerCase().equals("n"))
             {
                 actionOnUserChoice();
             }
         }
         else if(choice==2)
         {
             getDataFromDataStorage();
             sendDataToFrontEnd();
             System.out.print("Do you want to go to main menu ? (Y/N) : ");
             if(sc.next().toLowerCase().equals("y"))
             {
                 actionOnUserChoice();
             }
             else if(sc.next().toLowerCase().equals("n"))
             {
                 System.exit(0);
             }
         }
         else if(choice==3)
         {
             System.exit(0);
         }    
         else {
             System.out.println("Invalid Choice");
         }
     }
     
     public void sendDataToDaoClass()
     {
         //System.out.println("Data sent to dAO class");
         dsObj.storeDataIntoArrayList(Obj);
     }
     
     public void getDataFromDataStorage()
     {
         //System.out.println("Get data from storage called");
         mapOfOrderArrayList1 =  dsObj.getDataFromContainer();
         
     }
     
     public void sendDataToFrontEnd()
     {
         //System.out.println("Data sent to front end");
         OdObj.enterImportedDetails(mapOfOrderArrayList1);
         
     }
     
     

}


	 
