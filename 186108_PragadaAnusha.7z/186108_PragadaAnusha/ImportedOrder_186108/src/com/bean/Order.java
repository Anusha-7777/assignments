package com.bean;

public class Order
{
   private int ordid;
  
   private double ordprice;
   private int ordquantity;
   private double ordamount;
   private double ordcharges;
   
   public int getOrdId() {
       return ordid;
   }
   public void setOrdId(int ordId) {
       this.ordid = ordid;
   }
   public double getOrdprice() {
       return ordprice;
   }
   public void setOrdprice(double ordprice) {
       this.ordprice = ordprice;
   }
   public int getOrdquantity() {
       return ordquantity;
   }
   public void setOrdquantity(int ordquantity) {
       this.ordquantity = ordquantity;
   }
   public double getOrdamount() {
       return ordamount;
   }
   public void setOrdName(double ordamount) {
       this.ordamount = ordamount;
   }
   
   public double getOrdcharges() {
       return ordcharges;
   }
   public void setOrdcharges(double charges) {
       this.ordcharges= ordcharges;
   }

@Override
public String toString() {
	return "Order [id=" + ordid + ", price=" + ordprice + ", quantity=" + ordquantity + ", amount=" + ordamount + ", charges="
			+ ordcharges + "]";
}
public void setOrSerial(int nextInt) {
	// TODO Auto-generated method stub
	
}
public Object getOrdSerial() {
	// TODO Auto-generated method stub
	return null;
}
public void setOrdamount(double nextDouble) {
	// TODO Auto-generated method stub
	
}
   

}

