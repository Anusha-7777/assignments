package com.ui;
import java.util.*;
import com.bean.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

 




public class OrderDetails
{
static Scanner sc=new Scanner(System.in);
 public int displayMenu()
 {
	 System.out.println("Welcome to Imported Order Application");
     System.out.println("Press 1 to enter Order Details");
     System.out.println("Press 2 to enter display Order details");
     System.out.println("Press 3 to exit");
     System.out.print("Your choice : ");
     return sc.nextInt();
 }
 public void enterImportedDetails(Order or)
 {
	 
     System.out.print("Enter Order Id : ");
     or.setOrdId(sc.nextInt());
     
     System.out.print("Enter Order price : ");
     or.setOrdprice(sc.nextDouble());
     System.out.print("Enter Order quantity : ");
     or.setOrdquantity(sc.nextInt());
     System.out.print("Enter Order amount : ");
     or.setOrdamount(sc.nextDouble());
     System.out.print("Enter Order charges : ");
     or.setOrdcharges(sc.nextDouble());
 
     System.out.println("Data Entered Successfully\n");
     public void displayImportedDetails(Map mapOfOrderArrayList)
     {
         
         System.out.print("\nEnter Order Id : ");
         System.out.println(mapOfOrderArrayList.get(sc.nextInt()));
         
     }
 }

}
