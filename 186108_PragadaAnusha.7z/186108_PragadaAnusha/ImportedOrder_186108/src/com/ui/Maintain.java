package com.ui;


import com.bean.Order;
import com.dao.DataStorage;
import com.service.Service;

 

public class Maintain {
    
    public static void main(String[] args) {
        
        Order Obj = new Order();
        OrderDetails OdObj = new OrderDetails();
        DataStorage dsObj = new DataStorage();
        Service sObj = new Service(dsObj, OdObj, Obj);
        
        sObj.actionOnUserChoice();
    }
}
    
        
        
        
        
   