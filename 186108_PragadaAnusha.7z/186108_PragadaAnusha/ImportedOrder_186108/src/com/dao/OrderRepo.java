package com.dao;

import com.bean.Order;

public interface OrderRepo 
{
  int saveOrder(Order bean);
}
