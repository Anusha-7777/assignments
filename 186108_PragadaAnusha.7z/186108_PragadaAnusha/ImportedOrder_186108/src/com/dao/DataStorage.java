package com.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.bean.Order;

public class DataStorage
{
	//List listOfLists;
    @SuppressWarnings("rawtypes")
    ArrayList  orderData;
    Map mapOfOrderArrayList = new HashMap<>();
    
    
    int serial = 0;
    public DataStorage()
    {
        
    }
    
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public void storeDataIntoArrayList(Order or)
    {
        
        orderData = new ArrayList();      
        orderData.add(or.getOrdSerial());
        orderData.add(or.getOrdId());
        orderData.add(or.getOrdprice());
        orderData.add(or.getOrdquantity());
        orderData.add(or.getOrdamount());
        orderData.add(or.getOrdcharges());
       
        mapOfOrderArrayList.put(serial,new ArrayList( orderData));
        orderData.clear();
        
        
    }
    
    public Map getDataFromContainer()
    {
     
        return mapOfOrderArrayList;
    }

}
