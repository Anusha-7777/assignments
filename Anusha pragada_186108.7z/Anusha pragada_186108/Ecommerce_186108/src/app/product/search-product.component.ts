import { Component, OnInit } from '@angular/core';
import { IProduct } from './product interface';
import { ProductService } from './product.service';

@Component({
  selector: 'app-search-product',
  templateUrl: './search-product.component.html',
  styleUrls: ['./search-product.component.css']
})
export class SearchProductComponent implements OnInit {
  products:IProduct[];
  searchproduct:any;
  searchproducta:any;

  constructor(private productservice:ProductService) { }
  
/* this method is to get the list of products after searching */
  
ngOnInit() {
    this.productservice.getDetails().subscribe((data)=>this.products=data);

  }
  
  search(){
    this.searchproducta=this.searchproduct;
    }
    

}
