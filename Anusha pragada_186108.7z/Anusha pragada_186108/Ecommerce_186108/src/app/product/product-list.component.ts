import { Component, OnInit } from '@angular/core';
import { IProduct } from './product interface';
import { ProductService } from './product.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})

export class ProductListComponent implements OnInit {
products:IProduct[];
  constructor(private productservice:ProductService) { }

  /* this method is to get the list of products  */
  
  ngOnInit() {
    this.productservice.getDetails().subscribe((data)=>this.products=data);
    console.log(this.products);
  }
  
  /* this method is to delete a row in the table  */

  delete(product1){
    let a=this.products.indexOf(product1);
    this.products.splice(a,1);
}

}
