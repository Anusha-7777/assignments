import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IProduct } from './product interface';

@Injectable({
  providedIn: 'root'
})

export class ProductService {

  constructor(private http:HttpClient) { }
  
  /* this method is to fetch data from json file */

  getDetails():Observable<IProduct[]>{
    return this.http.get<IProduct[]>("./assets/db.json");
  }
}
