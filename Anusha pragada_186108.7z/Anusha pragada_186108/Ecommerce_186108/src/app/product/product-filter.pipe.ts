import { Pipe, PipeTransform } from '@angular/core';
import { IProduct } from './product interface';


@Pipe({
  name: 'productFilter'
})
/* this class is to filter data in table */

export class ProductFilterPipe implements PipeTransform {

  transform(products:IProduct[],searchproducta:number&string){
    if(!products||!searchproducta){
    return products;
  }
  return products.filter(products=>(products.name.toLowerCase().startsWith(searchproducta.toLowerCase())||products.category.toLowerCase().startsWith(searchproducta.toLowerCase())));
  
}
}
