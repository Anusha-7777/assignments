package com.cg;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class AuthorDetails {

	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		
		Author obj = new Author();
		em.getTransaction().begin();
		obj.setAuthorId(103);
		obj.setFirstname("gfgjk");
		obj.setLastname("asawws");
		obj.setPhoneno("9398944");
		em.persist(obj);

		System.out.println("Added greeting to database.");

		//Author obj1=em.find(Author.class, 102);
		//obj1.setFirstname("Anusha");
		
		//System.out.println(obj1);
		
		//em.remove(obj1);
		
		em.getTransaction().commit();
		
	}
}

