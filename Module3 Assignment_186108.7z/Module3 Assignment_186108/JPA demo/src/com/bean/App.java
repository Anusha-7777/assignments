package com.bean;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

public class App {
public static void main(String[] args) {
	EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");	
	EntityManager entityManager = factory.createEntityManager();

	/*entityManager.getTransaction().begin();
	Authors obj=new Authors();
	obj.setName("Anu");
	
	Book obj1=new Book();
	obj1.setTitle("Novel");
	obj1.setPrice(300.67);
	Book obj2=new Book();
	obj2.setTitle("story");
	obj2.setPrice(700.90);
	
	obj.getBk().add(obj1);
	obj.getBk().add(obj2);
	entityManager.persist(obj);
	
	System.out.println("Added greeting to database.");*/
	
	TypedQuery<Book> query1 = entityManager.createQuery("from Book", Book.class);
	List<Book> bookList = query1.getResultList();
	for(Book books:bookList) {
		System.out.println(books);
		
	}
	TypedQuery<Authors> query2=entityManager.createQuery("from Authors where name='Anu'", Authors.class);
    Authors authorId=query2.getSingleResult();
    int getId=authorId.getId();
    
    TypedQuery<Book> query3=entityManager.createQuery("from Book where ID=:id", Book.class);
    query3.setParameter("id", getId);
    List<Book> books2=query3.getResultList();
    for(Book book:books2) {
    System.out.println(book);
    }
    System.out.println();
	entityManager.getTransaction().commit();

	entityManager.close();
	factory.close();
   }
}

