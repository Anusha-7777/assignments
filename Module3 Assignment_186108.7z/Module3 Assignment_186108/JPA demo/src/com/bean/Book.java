package com.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity

public class Book {
@Id
@GeneratedValue
private int isbn;
private String Title;
private double Price;

public int getIsbn() {
	return isbn;
}
public void setIsbn(int isbn) {
	this.isbn = isbn;
}
public String getTitle() {
	return Title;
}
public void setTitle(String title) {
	Title = title;
}
public double getPrice() {
	return Price;
}
public void setPrice(double price) {
	Price = price;
}
@Override
public String toString() {
	return "Book [isbn=" + isbn + ", Title=" + Title + ", Price=" + Price + "]";
}
}



