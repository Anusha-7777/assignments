package com.bean;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;



@Entity
public class Authors {
@Id
@GeneratedValue

	private int Id;
	private String Name;
	@OneToMany(cascade=CascadeType.ALL)
	private List<Book> bk = new ArrayList<>();	
	public List<Book> getBk() {
		return bk;
	}
	public void setBk(List<Book> bk) {
		this.bk = bk;
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	@Override
	public String toString() {
		return "Authors [Id=" + Id + ", Name=" + Name + "]";
	}
	
}
